<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Barang extends Model
{
    use HasFactory;

    protected $table = 'barang';
    protected $primaryKey = 'ID_BARANG';
    public $timestamps = false;

    protected $fillable = [
        'ID_PEGAWAI',
        'ID_PENITIP',
        'NAMA_BARANG',
        'DESKRIPSI',
        'HARGA',
        'TANGGAL_MASUK',
        'TANGGAL_JUAL',
        'STATUS_BARANG',
        'STATUS_GARANSI',
        'TANGGAL_GARANSI',
        'ID_KATEGORI',
        'GAMBAR'
    ];

    protected $casts = [
        'TANGGAL_MASUK' => 'date',
        'TANGGAL_JUAL' => 'date',
        'TANGGAL_GARANSI' => 'date',
        'STATUS_GARANSI' => 'boolean',
        'HARGA' => 'decimal:2'
    ];

    public function pegawai()
    {
        return $this->belongsTo(Pegawai::class, 'ID_PEGAWAI', 'ID_PEGAWAI');
    }

    public function penitip()
    {
        return $this->belongsTo(Penitip::class, 'ID_PENITIP', 'ID_PENITIP');
    }

    public function kategori()
    {
        return $this->belongsTo(KategoriBarang::class, 'ID_KATEGORI', 'ID_KATEGORI');
    }

    public function detailPenitipan()
    {
        return $this->hasMany(DetailPenitipan::class, 'ID_BARANG', 'ID_BARANG');
    }

    public function detailTransaksi()
    {
        return $this->hasMany(DetailTransaksi::class, 'ID_BARANG', 'ID_BARANG');
    }

    public function donasi()
    {
        return $this->hasOne(Donasi::class, 'ID_BARANG', 'ID_BARANG');
    }

    public function diskusi()
    {
        return $this->hasMany(Diskusi::class, 'ID_BARANG', 'ID_BARANG');
    }

    public function komisi()
    {
        return $this->hasOne(Komisi::class, 'ID_BARANG', 'ID_BARANG');
    }
}