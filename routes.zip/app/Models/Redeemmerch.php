<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RedeemMerch extends Model
{
    use HasFactory;

    protected $table = 'redeem_merch';
    protected $primaryKey = 'ID_REDEEM';
    public $timestamps = false;

    protected $fillable = [
        'ID_PEMBELI',
        'TANGGAL_REDEEM'
    ];

    protected $casts = [
        'TANGGAL_REDEEM' => 'date',
    ];

    public function pembeli()
    {
        return $this->belongsTo(Pembeli::class, 'ID_PEMBELI', 'ID_PEMBELI');
    }

    public function detailRedeem()
    {
        return $this->hasMany(DetailRedeem::class, 'ID_REDEEM', 'ID_REDEEM');
    }
}