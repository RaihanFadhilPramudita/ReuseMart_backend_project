<?php

namespace App\Http\Controllers;

use App\Models\RequestDonasi;
use App\Models\Organisasi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;

class RequestDonasiController extends Controller
{
    public function index(Request $request)
    {
        $requestDonasi = RequestDonasi::query();
        
        if ($request->has('status')) {
            $requestDonasi->where('STATUS_REQUEST', $request->status);
        }
        
        if ($request->has('organization_id')) {
            $requestDonasi->where('ID_ORGANISASI', $request->organization_id);
        }
        
        $result = $requestDonasi->with('organisasi')
            ->orderBy('TANGGAL_REQUEST', 'desc')
            ->get();
            
        return response()->json(['data' => $result]);
    }

    public function show($id)
    {
        $requestDonasi = RequestDonasi::with(['organisasi', 'donasi'])->findOrFail($id);
        return response()->json(['data' => $requestDonasi]);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id_organisasi' => 'required|exists:organisasi,ID_ORGANISASI',
            'nama_barang' => 'required|string|max:255',
            'deskripsi' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $requestDonasi = new RequestDonasi();
        $requestDonasi->ID_ORGANISASI = $request->id_organisasi;
        $requestDonasi->NAMA_BARANG = $request->nama_barang;
        $requestDonasi->DESKRIPSI = $request->deskripsi;
        $requestDonasi->TANGGAL_REQUEST = Carbon::now();
        $requestDonasi->STATUS_REQUEST = 'Menunggu';
        $requestDonasi->save();

        return response()->json([
            'message' => 'Donation request submitted successfully',
            'data' => $requestDonasi->load('organisasi')
        ], 201);
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'nama_barang' => 'string|max:255',
            'deskripsi' => 'nullable|string',
            'status_request' => 'in:Menunggu,Disetujui,Ditolak,Terpenuhi',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $requestDonasi = RequestDonasi::findOrFail($id);
        
        if ($requestDonasi->STATUS_REQUEST === 'Terpenuhi') {
            return response()->json([
                'message' => 'Cannot update a fulfilled donation request'
            ], 422);
        }
        
        if($request->has('nama_barang')) $requestDonasi->NAMA_BARANG = $request->nama_barang;
        if($request->has('deskripsi')) $requestDonasi->DESKRIPSI = $request->deskripsi;
        if($request->has('status_request')) $requestDonasi->STATUS_REQUEST = $request->status_request;
        
        $requestDonasi->save();

        return response()->json([
            'message' => 'Donation request updated successfully',
            'data' => $requestDonasi
        ]);
    }

    public function destroy($id)
    {
        $requestDonasi = RequestDonasi::findOrFail($id);
        
        $hasDonations = $requestDonasi->donasi()->count() > 0;
        if ($hasDonations) {
            return response()->json([
                'message' => 'Cannot delete request with associated donations'
            ], 422);
        }
        
        $requestDonasi->delete();

        return response()->json(['message' => 'Donation request deleted successfully']);
    }

    public function organizationRequests($organizationId)
    {
        $requests = RequestDonasi::where('ID_ORGANISASI', $organizationId)
            ->orderBy('TANGGAL_REQUEST', 'desc')
            ->get();
            
        return response()->json(['data' => $requests]);
    }

    public function pendingRequests()
    {
        $pendingRequests = RequestDonasi::with('organisasi')
            ->where('STATUS_REQUEST', 'Menunggu')
            ->orderBy('TANGGAL_REQUEST', 'asc')
            ->get();
            
        return response()->json(['data' => $pendingRequests]);
    }

    public function search(Request $request)
    {
        $keyword = $request->input('q');
        if (!$keyword) return response()->json(['message' => 'Parameter q diperlukan.'], 422);

        $results = RequestDonasi::with('organisasi')
            ->where('JUDUL', 'like', "%{$keyword}%")
            ->orWhere('STATUS', 'like', "%{$keyword}%")
            ->orWhereHas('organisasi', function($q) use ($keyword) {
                $q->where('NAMA_ORGANISASI', 'like', "%{$keyword}%");
            })
            ->paginate(10);

        return response()->json(['data' => $results]);
    }

}