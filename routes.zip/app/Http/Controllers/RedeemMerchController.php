<?php

namespace App\Http\Controllers;

use App\Models\RedeemMerch;
use App\Models\DetailRedeem;
use App\Models\Merchandise;
use App\Models\Pembeli;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;

class RedeemMerchController extends Controller
{
    public function index()
    {
        $redeems = RedeemMerch::with(['pembeli', 'detailRedeem.merchandise'])->get();
        return response()->json(['data' => $redeems]);
    }

    public function show($id)
    {
        $redeem = RedeemMerch::with(['pembeli', 'detailRedeem.merchandise'])->findOrFail($id);
        return response()->json(['data' => $redeem]);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id_pembeli' => 'required|exists:pembeli,ID_PEMBELI',
            'items' => 'required|array',
            'items.*.id_merchandise' => 'required|exists:merchandise,ID_MERCHANDISE',
            'items.*.jumlah' => 'required|integer|min:1',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $totalPointsNeeded = 0;
        foreach ($request->items as $item) {
            $merchandise = Merchandise::findOrFail($item['id_merchandise']);
            $totalPointsNeeded += $merchandise->POIN_REQUIRED * $item['jumlah'];
            
            // Check stock availability
            if ($merchandise->STOK < $item['jumlah']) {
                return response()->json([
                    'message' => "Not enough stock for {$merchandise->NAMA_MERCHANDISE}"
                ], 422);
            }
        }
        
        $pembeli = Pembeli::findOrFail($request->id_pembeli);
        if (!isset($pembeli->poin) || $pembeli->poin < $totalPointsNeeded) {
            return response()->json([
                'message' => 'Not enough points',
                'required_points' => $totalPointsNeeded,
                'available_points' => $pembeli->poin ?? 0
            ], 422);
        }
        
        $redeem = new RedeemMerch();
        $redeem->ID_PEMBELI = $request->id_pembeli;
        $redeem->TANGGAL_REDEEM = Carbon::now();
        $redeem->save();
        
        foreach ($request->items as $item) {
            $detail = new DetailRedeem();
            $detail->ID_REDEEM = $redeem->ID_REDEEM;
            $detail->ID_MERCHANDISE = $item['id_merchandise'];
            $detail->JUMLAH_MERCH = $item['jumlah'];
            $detail->save();
            
            $merchandise = Merchandise::find($item['id_merchandise']);
            $merchandise->STOK -= $item['jumlah'];
            $merchandise->save();
        }
        
        if (isset($pembeli->poin)) {
            $pembeli->poin -= $totalPointsNeeded;
            $pembeli->save();
        }

        return response()->json([
            'message' => 'Redemption completed successfully',
            'data' => $redeem->load(['pembeli', 'detailRedeem.merchandise'])
        ], 201);
    }

    public function customerRedemptions($customerId)
    {
        $redeems = RedeemMerch::with(['detailRedeem.merchandise'])
            ->where('ID_PEMBELI', $customerId)
            ->orderBy('TANGGAL_REDEEM', 'desc')
            ->get();
            
        return response()->json(['data' => $redeems]);
    }

    public function cancel($id)
    {
        $redeem = RedeemMerch::with('detailRedeem.merchandise')->findOrFail($id);
        
        $redeemDate = Carbon::parse($redeem->TANGGAL_REDEEM);
        if ($redeemDate->diffInHours(Carbon::now()) > 24) {
            return response()->json([
                'message' => 'Redemption cannot be cancelled after 24 hours'
            ], 422);
        }
        
        foreach ($redeem->detailRedeem as $detail) {
            $merchandise = Merchandise::find($detail->ID_MERCHANDISE);
            if ($merchandise) {
                $merchandise->STOK += $detail->JUMLAH_MERCH;
                $merchandise->save();
            }
        }
        
        $totalPointsToRestore = 0;
        foreach ($redeem->detailRedeem as $detail) {
            $totalPointsToRestore += $detail->merchandise->POIN_REQUIRED * $detail->JUMLAH_MERCH;
        }
        
        $pembeli = Pembeli::find($redeem->ID_PEMBELI);
        if ($pembeli && isset($pembeli->poin)) {
            $pembeli->poin += $totalPointsToRestore;
            $pembeli->save();
        }
        
        DetailRedeem::where('ID_REDEEM', $redeem->ID_REDEEM)->delete();
        $redeem->delete();

        return response()->json(['message' => 'Redemption cancelled successfully']);
    }
}