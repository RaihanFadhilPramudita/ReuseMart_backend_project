<?php

namespace App\Http\Controllers;

use App\Models\KategoriBarang;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class KategoriBarangController extends Controller
{
    public function index()
    {
        $kategoris = KategoriBarang::all();
        return response()->json(['data' => $kategoris]);
    }

    public function show($id)
    {
        $kategori = KategoriBarang::findOrFail($id);
        return response()->json(['data' => $kategori]);
    }

    public function items($id)
    {
        $barang = \App\Models\Barang::where('ID_KATEGORI', $id)->with('penitip')->get();

        return response()->json(['data' => $barang]);
    }


}