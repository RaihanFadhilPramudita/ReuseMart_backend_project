<?php

namespace App\Http\Controllers;

use App\Models\Transaksi;
use App\Models\DetailTransaksi;
use App\Models\Barang;
use App\Models\Pembeli;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;

class TransaksiController extends Controller
{
    public function index(Request $request)
    {
        $transaksi = Transaksi::query();

        if ($request->has('status')) {
            $transaksi->where('STATUS_TRANSAKSI', $request->status);
        }

        if ($request->has('start_date') && $request->has('end_date')) {
            $transaksi->whereBetween('WAKTU_PESAN', [$request->start_date, $request->end_date]);
        }

        if ($request->has('pembeli_id')) {
            $transaksi->where('ID_PEMBELI', $request->pembeli_id);
        }

        $result = $transaksi->with(['pembeli', 'pegawai', 'detailTransaksi.barang'])
            ->orderBy('WAKTU_PESAN', 'desc')
            ->paginate(10);

        return response()->json(['data' => $result]);
    }

    public function show($id)
    {
        $transaksi = Transaksi::with(['pembeli', 'pegawai', 'detailTransaksi.barang', 'pengiriman', 'pengambilan'])
            ->findOrFail($id);

        return response()->json(['data' => $transaksi]);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id_pegawai' => 'required|exists:pegawai,ID_PEGAWAI',
            'id_pembeli' => 'required|exists:pembeli,ID_PEMBELI',
            'items' => 'required|array',
            'items.*.id_barang' => 'required|exists:barang,ID_BARANG',
            'items.*.jumlah' => 'required|integer|min:1',
            'jenis_delivery' => 'required|in:Antar,Ambil',
            'use_points' => 'boolean',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $pembeli = Pembeli::findOrFail($request->id_pembeli);

        $totalHarga = 0;
        $ongkosKirim = 0;
        $potonganPoin = 0;

        foreach ($request->items as $item) {
            $barang = Barang::findOrFail($item['id_barang']);
            if ($barang->STATUS_BARANG !== 'Tersedia') {
                return response()->json([
                    'message' => "Item {$barang->NAMA_BARANG} is not available"
                ], 422);
            }
            $totalHarga += $barang->HARGA * $item['jumlah'];
        }

        if ($request->jenis_delivery === 'Antar') {
            $ongkosKirim = ($totalHarga >= 1500000) ? 0 : 100000;
        }

        if ($request->use_points && $pembeli->POIN > 0) {
            $maxPointsDiscount = floor($pembeli->POIN / 100) * 10000;
            $potonganPoin = min($maxPointsDiscount, $totalHarga + $ongkosKirim);
            $poinDipakai = floor($potonganPoin / 10000) * 100;
            $pembeli->POIN -= $poinDipakai;
            $pembeli->save();
        }

        $totalAkhir = $totalHarga + $ongkosKirim - $potonganPoin;

        $pointsEarned = floor($totalHarga / 10000);
        if ($totalHarga > 500000) {
            $pointsEarned += floor($pointsEarned * 0.2);
        }

        $month = Carbon::now()->format('m');
        $year = Carbon::now()->format('y');
        $lastTransaction = Transaksi::orderBy('ID_TRANSAKSI', 'desc')->first();
        $lastNumber = $lastTransaction ? substr($lastTransaction->NO_NOTA, -3) : 0;
        $newNumber = str_pad((int)$lastNumber + 1, 3, '0', STR_PAD_LEFT);
        $noNota = $year . '.' . $month . '.' . $newNumber;

        $transaksi = new Transaksi();
        $transaksi->ID_PEGAWAI = $request->id_pegawai;
        $transaksi->ID_PEMBELI = $request->id_pembeli;
        $transaksi->NO_NOTA = $noNota;
        $transaksi->WAKTU_PESAN = Carbon::now();
        $transaksi->TOTAL_HARGA = $totalHarga;
        $transaksi->ONGKOS_KIRIM = $ongkosKirim;
        $transaksi->POTONGAN_POIN = $potonganPoin;
        $transaksi->TOTAL_AKHIR = $totalAkhir;
        $transaksi->POIN_DIDAPAT = $pointsEarned;
        $transaksi->STATUS_TRANSAKSI = 'Belum dibayar';
        $transaksi->JENIS_DELIVERY = $request->jenis_delivery;
        $transaksi->save();

        foreach ($request->items as $item) {
            $detail = new DetailTransaksi();
            $detail->ID_TRANSAKSI = $transaksi->ID_TRANSAKSI;
            $detail->ID_BARANG = $item['id_barang'];
            $detail->JUMLAH = $item['jumlah'];
            $detail->save();
        }

        return response()->json([
            'message' => 'Transaction created successfully',
            'data' => $transaksi->load(['detailTransaksi.barang'])
        ], 201);
    }

    public function uploadPaymentProof(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'bukti_transfer' => 'required|image|max:2048',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $transaksi = Transaksi::findOrFail($id);

        if ($transaksi->STATUS_TRANSAKSI !== 'Belum dibayar') {
            return response()->json(['message' => 'Transaction is not in unpaid status'], 422);
        }

        if ($request->hasFile('bukti_transfer')) {
            $file = $request->file('bukti_transfer');
            $fileName = 'payment_'.$transaksi->NO_NOTA.'_'.time().'.'.$file->getClientOriginalExtension();
            $file->storeAs('public/payment_proofs', $fileName);

            $transaksi->BUKTI_TRANSFER = $fileName;
            $transaksi->STATUS_TRANSAKSI = 'Menunggu Verifikasi';
            $transaksi->save();
        }

        return response()->json([
            'message' => 'Payment proof uploaded successfully',
            'data' => $transaksi
        ]);
    }

    public function verifyPayment(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'is_valid' => 'required|boolean',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $transaksi = Transaksi::findOrFail($id);

        if ($transaksi->STATUS_TRANSAKSI !== 'Menunggu Verifikasi') {
            return response()->json(['message' => 'Transaction is not in verification status'], 422);
        }

        if ($request->is_valid) {
            $transaksi->STATUS_VALIDASI_PEMBAYARAN = 'valid';
            $transaksi->STATUS_TRANSAKSI = 'Diproses';
            $transaksi->WAKTU_BAYAR = Carbon::now();
            $transaksi->TANGGAL_VERIFIKASI = Carbon::now();
        } else {
            $transaksi->STATUS_VALIDASI_PEMBAYARAN = 'pembayaran ditolak';
            $transaksi->STATUS_TRANSAKSI = 'pembayaran ditolak';
        }

        $transaksi->save();

        return response()->json([
            'message' => $request->is_valid ? 'Payment verified and processed' : 'Payment rejected',
            'data' => $transaksi
        ]);
    }

    public function updateStatus(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'status' => 'required|in:Diproses,Siap diambil,Sedang dikirim,Sudah diterima,Selesai',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $transaksi = Transaksi::findOrFail($id);

        $validTransition = false;
        switch ($transaksi->STATUS_TRANSAKSI) {
            case 'Sudah dibayar':
                $validTransition = $request->status === 'Diproses';
                break;
            case 'Diproses':
                $validTransition = in_array($request->status, ['Siap diambil', 'Sedang dikirim']);
                break;
            case 'Siap diambil':
            case 'Sedang dikirim':
                $validTransition = $request->status === 'Sudah diterima';
                break;
            case 'Sudah diterima':
                $validTransition = $request->status === 'Selesai';
                break;
        }

        if (!$validTransition) {
            return response()->json([
                'message' => 'Invalid status transition from ' . $transaksi->STATUS_TRANSAKSI . ' to ' . $request->status
            ], 422);
        }

        $transaksi->STATUS_TRANSAKSI = $request->status;

        if ($request->status === 'Selesai') {
            foreach ($transaksi->detailTransaksi as $detail) {
                $barang = Barang::find($detail->ID_BARANG);
                if ($barang) {
                    $barang->STATUS_BARANG = 'Sold Out';
                    $barang->TANGGAL_JUAL = Carbon::now();
                    $barang->save();
                }
            }

            $pembeli = $transaksi->pembeli;
            $pembeli->POIN += $transaksi->POIN_DIDAPAT;
            $pembeli->save();
        }

        $transaksi->save();

        return response()->json([
            'message' => 'Transaction status updated successfully',
            'data' => $transaksi
        ]);
    }

    public function cancel($id)
    {
        $transaksi = Transaksi::findOrFail($id);

        if (!in_array($transaksi->STATUS_TRANSAKSI, ['Belum dibayar', 'Menunggu Verifikasi'])) {
            return response()->json([
                'message' => 'Only unpaid or unverified transactions can be cancelled'
            ], 422);
        }

        $transaksi->STATUS_TRANSAKSI = 'Batal';
        $transaksi->save();

        return response()->json([
            'message' => 'Transaction cancelled successfully',
            'data' => $transaksi
        ]);
    }

    public function search(Request $request)
    {
        $keyword = $request->input('q');
        if (!$keyword) return response()->json(['message' => 'Parameter q diperlukan.'], 422);

        $results = Transaksi::with(['pembeli'])
            ->where('NO_NOTA', 'like', "%{$keyword}%")
            ->orWhere('STATUS_TRANSAKSI', 'like', "%{$keyword}%")
            ->orWhereHas('pembeli', function($q) use ($keyword) {
                $q->where('NAMA_PEMBELI', 'like', "%{$keyword}%");
            })
            ->paginate(10);

        return response()->json(['data' => $results]);
    }

    public function ongoingForCS()
    {
        $results = Transaksi::with(['pembeli'])
            ->where('STATUS_TRANSAKSI', 'Menunggu Verifikasi')
            ->select('ID_TRANSAKSI', 'ID_PEMBELI', 'BUKTI_TRANSFER')
            ->get()
            ->map(function ($item) {
                return [
                    'id_transaksi' => $item->ID_TRANSAKSI,
                    'nama_pembeli' => $item->pembeli->NAMA_PEMBELI ?? null,
                    'bukti_transfer' => asset('storage/payment_proofs/' . $item->BUKTI_TRANSFER),
                ];
            });

        return response()->json(['data' => $results]);
    }
}
