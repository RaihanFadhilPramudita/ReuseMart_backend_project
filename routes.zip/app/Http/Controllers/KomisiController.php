<?php

namespace App\Http\Controllers;

use App\Models\Komisi;
use App\Models\Penitip;
use App\Models\Pegawai;
use App\Models\Barang;
use App\Models\Transaksi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;

class KomisiController extends Controller
{
    public function index(Request $request)
    {
        $komisi = Komisi::query();
        
        if ($request->has('penitip_id')) {
            $komisi->where('ID_PENITIP', $request->penitip_id);
        }
        
        if ($request->has('pegawai_id')) {
            $komisi->where('ID_PEGAWAI', $request->pegawai_id);
        }
        
        if ($request->has('start_date') && $request->has('end_date')) {
            $komisi->whereBetween('TANGGAL_KOMISI', [$request->start_date, $request->end_date]);
        }
        
        $result = $komisi->with(['penitip', 'pegawai', 'barang'])
            ->orderBy('TANGGAL_KOMISI', 'desc')
            ->get();
            
        return response()->json(['data' => $result]);
    }

    public function show($id)
    {
        $komisi = Komisi::with(['penitip', 'pegawai', 'barang'])->findOrFail($id);
        return response()->json(['data' => $komisi]);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id_barang' => 'required|exists:barang,ID_BARANG',
            'id_transaksi' => 'required|exists:transaksi,ID_TRANSAKSI',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $existing = Komisi::where('ID_BARANG', $request->id_barang)->first();
        if ($existing) {
            return response()->json(['message' => 'Komisi sudah tercatat untuk barang ini.'], 422);
        }

        $calc = $this->calculateCommission($request)->getData();

        $barang = Barang::with('penitip')->findOrFail($request->id_barang);

        $komisi = new Komisi();
        $komisi->ID_PENITIP = $barang->ID_PENITIP;
        $komisi->ID_BARANG = $barang->ID_BARANG;
        $komisi->ID_PEGAWAI = $calc->is_hunted ? $barang->ID_PEGAWAI : null;
        $komisi->JUMLAH_KOMISI_REUSE_MART = $calc->reuse_mart_commission;
        $komisi->JUMLAH_KOMISI_HUNTER = $calc->hunter_commission ?? 0;
        $komisi->BONUS_PENITIP = $calc->bonus ?? 0;
        $komisi->TANGGAL_KOMISI = now();
        $komisi->save();

        $totalKomisi = $calc->total_commission;
        $penerimaan = $calc->price - $totalKomisi + $calc->bonus;

        $penitip = $barang->penitip;
        if ($penitip) {
            $penitip->SALDO += $penerimaan;
            $penitip->save();
        }

        return response()->json([
            'message' => 'Komisi otomatis tercatat',
            'data' => $komisi->load(['penitip', 'pegawai', 'barang'])
        ]);
    }


    public function calculateCommission(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id_barang' => 'required|exists:barang,ID_BARANG',
            'id_transaksi' => 'required|exists:transaksi,ID_TRANSAKSI',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $barang = Barang::with('penitip')->findOrFail($request->id_barang);
        $transaksi = Transaksi::findOrFail($request->id_transaksi);
        
        $isSold = false;
        foreach ($transaksi->detailTransaksi as $detail) {
            if ($detail->ID_BARANG == $barang->ID_BARANG) {
                $isSold = true;
                break;
            }
        }
        
        if (!$isSold) {
            return response()->json([
                'message' => 'Item is not included in this transaction'
            ], 422);
        }
        
        $salesDate = Carbon::parse($transaksi->WAKTU_PESAN);
        $entryDate = Carbon::parse($barang->TANGGAL_MASUK);
        $soldQuickly = $entryDate->diffInDays($salesDate) < 7;
        
        $isHunted = $barang->pegawai && $barang->pegawai->ID_JABATAN == 6; 
        
        $price = $barang->HARGA;
        $commissionRate = 0.20; 
        
        $penitipan = $barang->detailPenitipan()->first();
        if ($penitipan && $penitipan->penitipan) {
            $expirationDate = Carbon::parse($penitipan->penitipan->TANGGAL_KADALUARSA);
            $creationDate = Carbon::parse($penitipan->penitipan->TANGGAL_MASUK);
            
            if ($expirationDate->diffInDays($creationDate) > 30) {
                $commissionRate = 0.30; 
            }
        }
        
        $totalCommission = $price * $commissionRate;
        $hunterCommission = $isHunted ? $totalCommission * 0.25 : 0; 
        $reuseMartCommission = $totalCommission - $hunterCommission;
        
        $bonus = $soldQuickly ? $totalCommission * 0.10 : 0; 
        
        $isTopSeller = $barang->penitip && $barang->penitip->BADGE === 'Top Seller';
        if ($isTopSeller) {
            $bonus += $totalCommission * 0.01; 
        }
        
        return response()->json([
            'price' => $price,
            'commission_rate' => $commissionRate,
            'total_commission' => $totalCommission,
            'reuse_mart_commission' => $reuseMartCommission,
            'hunter_commission' => $hunterCommission,
            'bonus' => $bonus,
            'is_hunted' => $isHunted,
            'sold_quickly' => $soldQuickly,
            'is_top_seller' => $isTopSeller
        ]);
    }

    public function staffCommissionHistory($staffId)
    {
        $komisi = Komisi::with(['barang'])
            ->where('ID_PEGAWAI', $staffId)
            ->orderBy('TANGGAL_KOMISI', 'desc')
            ->get();
            
        return response()->json(['data' => $komisi]);
    }

    public function depositorCommissionHistory(Request $request)
    {
        $penitip = $request->user();

        if (!$penitip || !$penitip->ID_PENITIP) {
            return response()->json(['message' => 'Unauthorized'], 401);
        }

        $komisi = Komisi::with(['barang'])
            ->where('ID_PENITIP', $penitip->ID_PENITIP)
            ->orderBy('TANGGAL_KOMISI', 'desc')
            ->get();

        return response()->json(['data' => $komisi]);
    }
}