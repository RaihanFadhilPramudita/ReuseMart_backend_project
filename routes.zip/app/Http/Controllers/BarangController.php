<?php

namespace App\Http\Controllers;

use App\Models\Barang;
use App\Models\KategoriBarang;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;

class BarangController extends Controller
{
    public function index(Request $request)
    {
        $barangs = Barang::query();
        
        if ($request->has('kategori')) {
            $barangs->where('ID_KATEGORI', $request->kategori);
        }
        
        if ($request->has('status')) {
            $barangs->where('STATUS_BARANG', $request->status);
        }
        
        if ($request->has('min_price')) {
            $barangs->where('HARGA', '>=', $request->min_price);
        }
        
        if ($request->has('max_price')) {
            $barangs->where('HARGA', '<=', $request->max_price);
        }
        
        if ($request->has('search')) {
            $search = $request->search;
            $barangs->where(function($query) use ($search) {
                $query->where('NAMA_BARANG', 'like', "%{$search}%")
                      ->orWhere('DESKRIPSI', 'like', "%{$search}%");
            });
        }
        
        $result = $barangs->with(['kategori', 'penitip'])->paginate(10);

        $result->getCollection()->transform(function ($barang) {
            $barang->GAMBAR_URL = $barang->GAMBAR ? asset('storage/' . $barang->GAMBAR) : null;
            return $barang;
        });

        return response()->json(['data' => $result]);
    }

    public function search(Request $request)
    {
        $keyword = $request->input('q');

        if (!$keyword) {
            return response()->json(['message' => 'Parameter pencarian (q) wajib diisi.'], 422);
        }

        $barangs = Barang::with(['kategori', 'penitip'])
            ->where('NAMA_BARANG', 'like', "%{$keyword}%")
            ->orWhere('DESKRIPSI', 'like', "%{$keyword}%")
            ->orWhere('STATUS_BARANG', 'like', "%{$keyword}%")
            ->orWhere('HARGA', 'like', "%{$keyword}%")
            ->orWhereHas('kategori', function ($query) use ($keyword) {
                $query->where('NAMA_KATEGORI', 'like', "%{$keyword}%");
            })
            ->orWhereHas('penitip', function ($query) use ($keyword) {
                $query->where('NAMA_PENITIP', 'like', "%{$keyword}%");
            })
            ->paginate(10);

        $barangs->getCollection()->transform(function ($barang) {
            $barang->GAMBAR_URL = $barang->GAMBAR ? asset('storage/' . $barang->GAMBAR) : null;
            return $barang;
        });

        return response()->json(['data' => $barangs]);
    }


    public function show($id)
    {
        $barang = Barang::with(['kategori', 'penitip'])->findOrFail($id);

        if ($barang->GAMBAR) {
            $barang->GAMBAR_URL = asset('storage/' . $barang->GAMBAR);
        }

        return response()->json(['data' => $barang]);
    }


    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id_penitip' => 'required|exists:penitip,ID_PENITIP',
            'nama_barang' => 'required|string|max:255',
            'deskripsi' => 'required|string',
            'harga' => 'required|numeric|min:0',
            'status_garansi' => 'boolean',
            'tanggal_garansi' => 'nullable|date',
            'id_kategori' => 'required|exists:kategori_barang,ID_KATEGORI',
            'gambar' => 'required|image|max:2048',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $pegawai = auth('sanctum')->user();

        if (!$pegawai || !isset($pegawai->ID_PEGAWAI)) {
            return response()->json(['error' => 'Unauthorized or invalid user type'], 401);
        }

        $barang = new Barang();
        $barang->ID_PEGAWAI = $pegawai->ID_PEGAWAI;
        $barang->ID_PENITIP = $request->id_penitip;
        $barang->NAMA_BARANG = $request->nama_barang;
        $barang->DESKRIPSI = $request->deskripsi;
        $barang->HARGA = $request->harga;
        $barang->TANGGAL_MASUK = now();
        $barang->STATUS_BARANG = 'Tersedia';
        $barang->STATUS_GARANSI = $request->status_garansi ?? false;
        $barang->TANGGAL_GARANSI = $request->tanggal_garansi;
        $barang->ID_KATEGORI = $request->id_kategori;

        if ($request->hasFile('gambar')) {
            $path = $request->file('gambar')->store('barang', 'public');
            $barang->GAMBAR = $path;
        }

        $barang->save();

        return response()->json([
            'message' => 'Item added successfully',
            'data' => $barang
        ], 201);
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'nama_barang' => 'string|max:255',
            'deskripsi' => 'string',
            'harga' => 'numeric|min:0',
            'status_barang' => 'in:Tersedia,Sold Out',
            'status_garansi' => 'boolean',
            'tanggal_garansi' => 'nullable|date',
            'id_kategori' => 'exists:kategori_barang,ID_KATEGORI',
            'gambar' => 'nullable|image|max:2048', // tidak wajib diubah
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $barang = Barang::findOrFail($id);

        if (!$barang->GAMBAR && !$request->hasFile('gambar')) {
            return response()->json(['error' => 'Gambar wajib ada.'], 422);
        }

        if ($request->has('nama_barang')) $barang->NAMA_BARANG = $request->nama_barang;
        if ($request->has('deskripsi')) $barang->DESKRIPSI = $request->deskripsi;
        if ($request->has('harga')) $barang->HARGA = $request->harga;
        if ($request->has('status_barang')) $barang->STATUS_BARANG = $request->status_barang;
        if ($request->has('status_garansi')) $barang->STATUS_GARANSI = $request->status_garansi;
        if ($request->has('tanggal_garansi')) $barang->TANGGAL_GARANSI = $request->tanggal_garansi;
        if ($request->has('id_kategori')) $barang->ID_KATEGORI = $request->id_kategori;

 
        if ($request->hasFile('gambar')) {
            if ($barang->GAMBAR && Storage::disk('public')->exists($barang->GAMBAR)) {
                Storage::disk('public')->delete($barang->GAMBAR);
            }

            $path = $request->file('gambar')->store('barang', 'public');
            $barang->GAMBAR = $path;
        }

        $barang->save();

        return response()->json([
            'message' => 'Item updated successfully',
            'data' => $barang
        ]);
    }


    public function soldOut($id)
    {
        $barang = Barang::findOrFail($id);
        $barang->STATUS_BARANG = 'Sold Out';
        $barang->TANGGAL_JUAL = now();
        $barang->save();

        return response()->json([
            'message' => 'Item marked as sold',
            'data' => $barang
        ]);
    }

    public function searchGudang(Request $request)
    {
        $keyword = $request->input('q');
        if (!$keyword) return response()->json(['message' => 'Parameter q diperlukan.'], 422);

        $barangs = Barang::with(['kategori', 'penitip'])
            ->where('NAMA_BARANG', 'like', "%{$keyword}%")
            ->orWhere('DESKRIPSI', 'like', "%{$keyword}%")
            ->orWhere('STATUS_BARANG', 'like', "%{$keyword}%")
            ->orWhereHas('penitip', function ($q) use ($keyword) {
                $q->where('NAMA_PENITIP', 'like', "%{$keyword}%");
            })
            ->paginate(10);

        return response()->json(['data' => $barangs]);
    }

    public function searchPenitip(Request $request)
    {
        $keyword = $request->input('q');
        $penitipId = $request->user()->ID_PENITIP ?? null;

        if (!$keyword || !$penitipId) return response()->json(['message' => 'Parameter tidak lengkap.'], 422);

        $barangs = Barang::with(['kategori'])
            ->where('ID_PENITIP', $penitipId)
            ->where(function($q) use ($keyword) {
                $q->where('NAMA_BARANG', 'like', "%{$keyword}%")
                ->orWhere('DESKRIPSI', 'like', "%{$keyword}%")
                ->orWhere('STATUS_BARANG', 'like', "%{$keyword}%");
            })
            ->paginate(10);

        return response()->json(['data' => $barangs]);
    }

}