<?php

namespace App\Http\Controllers;

use App\Models\Pegawai;
use App\Models\Jabatan;
use App\Models\Komisi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class PegawaiController extends Controller
{
    
   public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'username' => 'required|string',
            'password' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $user = Pegawai::where('username', $request->username)->first();
        
        if (!$user || !Hash::check($request->password, $user->PASSWORD)) {
            return response()->json([
                'message' => 'Invalid credentials'
            ], 401);
        }

        $token = $user->createToken('PegawaiToken')->plainTextToken;

        $user->load(['jabatan']);

        return response()->json([
            'message' => 'Login successful',
            'token' => $token,
            'user' => $user
        ]);
    }

    public function logout(Request $request)
    {
        $pegawai = Auth::guard('pegawai')->user();
        
        if (!$pegawai) {
            return response()->json(['message' => 'Unauthorized'], 401);
        }

        $request->user('pegawai')->currentAccessToken()->delete();
        return response()->json(['message' => 'Pegawai logged out successfully']);
    }


    public function resetPasswordByBirthdate(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:pegawai,EMAIL',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $pegawai = Pegawai::where('EMAIL', $request->email)->first();

        if (!$pegawai || !$pegawai->TANGGAL_LAHIR) {
            return response()->json(['message' => 'Employee or birthdate not found'], 404);
        }

        $newPasswordPlain = Carbon::parse($pegawai->TANGGAL_LAHIR)->format('Ymd');
        $pegawai->PASSWORD = Hash::make($newPasswordPlain);
        $pegawai->save();

        return response()->json([
            'message' => 'Password has been reset using birthdate.',
            'new_password' => $newPasswordPlain  
        ]);
    }

    
    
    public function index()
    {
        $pegawai = Pegawai::with(['jabatan'])->get();
        return response()->json(['data' => $pegawai]);
    }
    
    public function profile(Request $request)
    {
        return response()->json(['data' => $request->user()->load(['jabatan'])]);
    }
    
    public function show($id)
    {
        $pegawai = Pegawai::with(['jabatan'])->findOrFail($id);
        return response()->json(['data' => $pegawai]);
    }
    
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id_jabatan' => 'required|exists:jabatan,ID_JABATAN',
            'email' => 'required|email|unique:pegawai,EMAIL',
            'password' => 'required|string|min:6',
            'nama_pegawai' => 'required|string|max:255',
            'no_telepon' => 'required|string|max:20',
            'tanggal_lahir' => 'required|date',
            'username' => 'required|string|max:255|unique:pegawai,USERNAME',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }
        
        $pegawai = new Pegawai();
        $pegawai->ID_JABATAN = $request->id_jabatan;
        $pegawai->EMAIL = $request->email;
        $pegawai->PASSWORD = Hash::make($request->password); 
        $pegawai->NAMA_PEGAWAI = $request->nama_pegawai;
        $pegawai->NO_TELEPON = $request->no_telepon;
        $pegawai->TANGGAL_LAHIR = $request->tanggal_lahir;
        $pegawai->TANGGAL_BERGABUNG = Carbon::now();
        $pegawai->USERNAME = $request->username;
        $pegawai->save();
        
        return response()->json([
            'message' => 'Employee created successfully',
            'data' => $pegawai->load(['jabatan'])
        ], 201);
    }

    public function search(Request $request)
    {
        $keyword = $request->input('q');

        if (!$keyword) {
            return response()->json(['message' => 'Parameter q diperlukan.'], 422);
        }

        $pegawai = Pegawai::with('jabatan')
            ->where('NAMA_PEGAWAI', 'like', "%{$keyword}%")
            ->orWhere('EMAIL', 'like', "%{$keyword}%")
            ->orWhere('NO_TELEPON', 'like', "%{$keyword}%")
            ->orWhere('USERNAME', 'like', "%{$keyword}%")
            ->orWhereHas('jabatan', function ($q) use ($keyword) {
                $q->where('NAMA_JABATAN', 'like', "%{$keyword}%");
            })
            ->paginate(10);

        return response()->json(['data' => $pegawai]);
    }

    
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'id_jabatan' => 'exists:jabatan,ID_JABATAN',
            'email' => 'email|unique:pegawai,EMAIL,'.$id.',ID_PEGAWAI',
            'nama_pegawai' => 'string|max:255',
            'no_telepon' => 'string|max:20',
            'tanggal_lahir' => 'date',
            'username' => 'string|max:255|unique:pegawai,USERNAME,'.$id.',ID_PEGAWAI',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }
        
        $pegawai = Pegawai::findOrFail($id);
        
        if($request->has('id_jabatan')) $pegawai->ID_JABATAN = $request->id_jabatan;
        if($request->has('email')) $pegawai->EMAIL = $request->email;
        if($request->has('nama_pegawai')) $pegawai->NAMA_PEGAWAI = $request->nama_pegawai;
        if($request->has('no_telepon')) $pegawai->NO_TELEPON = $request->no_telepon;
        if($request->has('tanggal_lahir')) $pegawai->TANGGAL_LAHIR = $request->tanggal_lahir;
        if($request->has('username')) $pegawai->USERNAME = $request->username;
        
        $pegawai->save();
        
        return response()->json([
            'message' => 'Employee updated successfully',
            'data' => $pegawai->load(['jabatan', 'supervisor'])
        ]);
    }
    
    public function destroy($id)
    {
        $pegawai = Pegawai::findOrFail($id);
        
        $subordinatesCount = Pegawai::where('PEG_ID_PEGAWAI', $id)->count();
        if ($subordinatesCount > 0) {
            return response()->json([
                'message' => 'Cannot delete employee with subordinates',
                'subordinates_count' => $subordinatesCount
            ], 422);
        }
        
        $organizationsCount = $pegawai->whereHas('organisasi')->count();
        if ($organizationsCount > 0) {
            return response()->json([
                'message' => 'Cannot delete employee referenced in organizations',
                'organizations_count' => $organizationsCount
            ], 422);
        }
        
        $pegawai->delete();
        
        return response()->json(['message' => 'Employee deleted successfully']);
    }
    
    public function subordinates($id)
    {
        $subordinates = Pegawai::with(['jabatan'])
            ->where('PEG_ID_PEGAWAI', $id)
            ->get();
            
        return response()->json(['data' => $subordinates]);
    }
    
    public function commissions($id)
    {
        $komisi = Komisi::with(['barang'])
            ->where('ID_PEGAWAI', $id)
            ->orderBy('TANGGAL_KOMISI', 'desc')
            ->get();
            
        return response()->json(['data' => $komisi]);
    }
    
    public function positionStaff($jabatanId)
    {
        $staff = Pegawai::where('ID_JABATAN', $jabatanId)->get();
        return response()->json(['data' => $staff]);
    }
    
    public function changePassword(Request $request, $id = null)
    {
        if (!$id && $request->user()) {
            $id = $request->user()->ID_PEGAWAI;
        }
        
        $validator = Validator::make($request->all(), [
            'current_password' => 'required',
            'new_password' => 'required|string|min:6|different:current_password',
            'confirm_password' => 'required|same:new_password',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }
        
        $pegawai = Pegawai::findOrFail($id);
        
        if (!Hash::check($request->current_password, $pegawai->PASWORD)) { // Note: DB field has typo "PASWORD"
            return response()->json(['message' => 'Current password is incorrect'], 422);
        }
        
        $pegawai->PASWORD = Hash::make($request->new_password); // Note: DB field has typo "PASWORD"
        $pegawai->save();
        
        return response()->json(['message' => 'Password changed successfully']);
    }

}