<?php

namespace App\Http\Controllers;

use App\Models\Donasi;
use App\Models\Barang;
use App\Models\RequestDonasi;
use App\Models\Penitip;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;

class DonasiController extends Controller
{
    public function index()
    {
        $requestDonasi = RequestDonasi::with(['barang', 'organisasi'])->where('status', 'pending')->get();
        return response()->json($requestDonasi);
    }


    public function show($id)
    {
        $donasi = Donasi::with(['barang', 'requestDonasi.organisasi'])->findOrFail($id);
        return response()->json(['data' => $donasi]);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id_barang' => 'required|exists:barang,ID_BARANG',
            'id_request' => 'required|exists:request_donasi,ID_REQUEST',
            'nama_penerima' => 'required|string|max:255',
            'jenis_barang' => 'nullable|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $barang = Barang::findOrFail($request->id_barang);
        if ($barang->STATUS_BARANG !== 'Tersedia') {
            return response()->json([
                'message' => 'Item is not available for donation'
            ], 422);
        }
        
        $existingDonation = Donasi::where('ID_BARANG', $request->id_barang)->first();
        if ($existingDonation) {
            return response()->json([
                'message' => 'Item has already been donated',
                'data' => $existingDonation
            ], 422);
        }
        
        $donasi = new Donasi();
        $donasi->ID_BARANG = $request->id_barang;
        $donasi->ID_REQUEST = $request->id_request;
        $donasi->TANGGAL_DONASI = Carbon::now();
        $donasi->NAMA_PENERIMA = $request->nama_penerima;
        $donasi->JENIS_BARANG = $request->jenis_barang;
        $donasi->save();
        
        $barang->STATUS_BARANG = 'Didonasikan';
        $barang->save();
        
        if ($barang->ID_PENITIP) {
            $penitip = Penitip::find($barang->ID_PENITIP);
            if ($penitip) {
                // Calculate points (1 point per Rp. 10,000)
                $points = floor($barang->HARGA / 10000);
                
                if (isset($penitip->poin_sosial)) {
                    $penitip->poin_sosial += $points;
                    $penitip->save();
                }
            }
        }

        return response()->json([
            'message' => 'Donation recorded successfully',
            'data' => $donasi->load(['barang', 'requestDonasi.organisasi'])
        ], 201);
    }


    public function report(Request $request)
    {
        $query = Donasi::with(['barang', 'requestDonasi.organisasi']);
        
        if ($request->has('start_date') && $request->has('end_date')) {
            $query->whereBetween('TANGGAL_DONASI', [$request->start_date, $request->end_date]);
        }
        
        if ($request->has('organization_id')) {
            $query->whereHas('requestDonasi', function($q) use ($request) {
                $q->where('ID_ORGANISASI', $request->organization_id);
            });
        }
        
        $donasi = $query->orderBy('TANGGAL_DONASI', 'desc')->get();
        
        return response()->json(['data' => $donasi]);
    }

    public function search(Request $request)
    {
        $keyword = $request->input('q');
        if (!$keyword) return response()->json(['message' => 'Parameter q diperlukan.'], 422);

        $results = Donasi::where('NAMA_DONASI', 'like', "%{$keyword}%")
            ->orWhere('KETERANGAN', 'like', "%{$keyword}%")
            ->paginate(10);

        return response()->json(['data' => $results]);
    }

    public function update(Request $request, $id)
    {
        $donasi = Donasi::findOrFail($id);

        $validator = Validator::make($request->all(), [
            'TANGGAL_DONASI' => 'nullable|date',
            'NAMA_PENERIMA' => 'nullable|string|max:255',
            'STATUS_BARANG' => 'nullable|string|in:pending,dikirim,selesai',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $donasi->update($validator->validated());

        return response()->json([
            'message' => 'Data donasi diperbarui',
            'data' => $donasi
        ]);
    }


}