<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Password;
use App\Models\Penitip;
use App\Models\Barang;
use App\Models\Penitipan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class PenitipController extends Controller
{
    
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $user = Penitip::where('EMAIL', $request->email)->first();
        
        if (!$user || !Hash::check($request->password, $user->PASSWORD)) {
            return response()->json([
                'message' => 'Invalid credentials'
            ], 401);
        }

        $token = $user->createToken('PenitipToken')->plainTextToken;

        return response()->json([
            'message' => 'Login successful',
            'token' => $token,
            'user' => $user
        ]);
    }

    public function logout(Request $request)
    {
        
        $penitip = Auth::guard('penitip')->user();
        if (!$penitip) {
            return response()->json(['message' => 'Unauthorized'], 401);
        }

        $request->user('penitip')->currentAccessToken()->delete();
        return response()->json(['message' => 'Penitip logged out successfully']);
    }

    public function forgotPassword(Request $request)
    {
        $request->validate([
            'email' => 'required|email|exists:penitip,EMAIL',
        ]);

        $status = Password::broker('penitips')->sendResetLink(
            ['email' => $request->email]
        );

        return $status === Password::RESET_LINK_SENT
            ? response()->json(['message' => 'Reset link sent to your email.'])
            : response()->json(['message' => 'Failed to send reset link.'], 500);
    }
    
    public function search(Request $request)
    {
        $keyword = $request->input('q');

        if (!$keyword) {
            return response()->json(['message' => 'Parameter q diperlukan.'], 422);
        }

        $penitip = Penitip::where('NAMA_PENITIP', 'like', "%{$keyword}%")
            ->orWhere('EMAIL', 'like', "%{$keyword}%")
            ->orWhere('NO_TELP', 'like', "%{$keyword}%")
            ->orWhere('USERNAME', 'like', "%{$keyword}%")
            ->paginate(10);

        return response()->json(['data' => $penitip]);
    }


    public function index()
    {
        $penitips = Penitip::all();
        return response()->json(['data' => $penitips]);
    }

    public function profile(Request $request)
    {
        return response()->json(['data' => $request->user()]);
    }

    public function show($id)
    {
        $penitip = Penitip::findOrFail($id);
        return response()->json(['data' => $penitip]);
    }

     public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|unique:penitip,EMAIL',
            'password' => 'required|min:6',
            'nama_penitip' => 'required|string|max:255',
            'no_telepon' => 'required|string|max:20',
            'no_ktp' => 'required|string|max:20|unique:penitip,NO_KTP',
            'tanggal_lahir' => 'required|date',
            'foto_ktp' => 'required|image|max:2048',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $path = $request->file('foto_ktp')->store('ktp', 'public');

        $penitip = new Penitip();
        $penitip->EMAIL = $request->email;
        $penitip->PASSWORD = Hash::make($request->password);
        $penitip->NAMA_PENITIP = $request->nama_penitip;
        $penitip->NO_TELEPON = $request->no_telepon;
        $penitip->NO_KTP = $request->no_ktp;
        $penitip->FOTO_KTP = $path;
        $penitip->TANGGAL_LAHIR = $request->tanggal_lahir;
        $penitip->TANGGAL_REGISTRASI = now();
        $penitip->SALDO = 0;
        $penitip->BADGE = 'Seller';
        $penitip->RATING = 0;
        $penitip->save();

        return response()->json([
            'message' => 'Depositor registered successfully',
            'data' => $penitip
        ], 201);
    }

    public function update(Request $request, $id = null)
    {
        if (!$id && $request->user()) {
            $id = $request->user()->ID_PENITIP;
        }

        $validator = Validator::make($request->all(), [
            'email' => 'email|unique:penitip,EMAIL,' . $id . ',ID_PENITIP',
            'nama_penitip' => 'string|max:255',
            'no_telepon' => 'string|max:20',
            'no_ktp' => 'string|max:20|unique:penitip,NO_KTP,' . $id . ',ID_PENITIP',
            'tanggal_lahir' => 'date',
            'foto_ktp' => 'nullable|image|max:2048',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $penitip = Penitip::findOrFail($id);

        if ($request->hasFile('foto_ktp')) {
            if ($penitip->FOTO_KTP && Storage::disk('public')->exists($penitip->FOTO_KTP)) {
                Storage::disk('public')->delete($penitip->FOTO_KTP);
            }
            $penitip->FOTO_KTP = $request->file('foto_ktp')->store('ktp', 'public');
        }

        if ($request->has('email')) $penitip->EMAIL = $request->email;
        if ($request->has('nama_penitip')) $penitip->NAMA_PENITIP = $request->nama_penitip;
        if ($request->has('no_telepon')) $penitip->NO_TELEPON = $request->no_telepon;
        if ($request->has('no_ktp')) $penitip->NO_KTP = $request->no_ktp;
        if ($request->has('tanggal_lahir')) $penitip->TANGGAL_LAHIR = $request->tanggal_lahir;

        $penitip->save();

        return response()->json([
            'message' => 'Profile updated successfully',
            'data' => $penitip
        ]);
    }

    public function itemHistory(Request $request, $id = null)
    {
        if (!$id && $request->user()) {
            $id = $request->user()->ID_PENITIP;
        }
        
        $barangs = Barang::where('ID_PENITIP', $id)->get();
        return response()->json(['data' => $barangs]);
    }

    public function depositHistory(Request $request, $id = null)
    {
        if (!$id && $request->user()) {
            $id = $request->user()->ID_PENITIP;
        }
        
        $penitipan = Penitipan::with('detailPenitipan.barang')
            ->where('ID_PENITIP', $id)
            ->orderBy('TANGGAL_MASUK', 'desc')
            ->get();
            
        return response()->json(['data' => $penitipan]);
    }

    public function showBalance(Request $request, $id = null)
    {
        if (!$id && $request->user()) {
            $id = $request->user()->ID_PENITIP;
        }
        
        $penitip = Penitip::findOrFail($id);
        return response()->json(['saldo' => $penitip->SALDO]);
    }

    public function changePassword(Request $request, $id = null)
    {
        if (!$id && $request->user()) {
            $id = $request->user()->ID_PENITIP;
        }
        
        $validator = Validator::make($request->all(), [
            'current_password' => 'required',
            'new_password' => 'required|min:6|different:current_password',
            'confirm_password' => 'required|same:new_password',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $penitip = Penitip::findOrFail($id);
        
        if (!Hash::check($request->current_password, $penitip->PASSWORD)) {
            return response()->json(['message' => 'Current password is incorrect'], 422);
        }

        $penitip->PASSWORD = Hash::make($request->new_password);
        $penitip->save();

        return response()->json(['message' => 'Password changed successfully']);
    }
}