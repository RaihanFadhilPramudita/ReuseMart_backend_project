<?php

namespace App\Http\Controllers;

use App\Models\Diskusi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
class DiskusiController extends Controller
{

    public function index()
    {
        $diskusi = Diskusi::with(['barang', 'pembeli', 'pegawai'])->orderBy('ID_DISKUSI', 'desc')->get();
        return response()->json(['data' => $diskusi]);
    }


    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id_barang' => 'required|exists:barang,ID_BARANG',
            'isi_pesan' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $diskusi = new Diskusi();
        $diskusi->ID_BARANG = $request->id_barang;
        $diskusi->ISI_PESAN = $request->isi_pesan;

        if (Auth::guard('pembeli')->check()) {
            $pembeli = Auth::guard('pembeli')->user();
            $diskusi->ID_PEMBELI = $pembeli->ID_PEMBELI;
            $diskusi->save();

            return response()->json([
                'message' => 'Message added from pembeli',
                'data' => $diskusi->load(['pembeli'])
            ]);
        } elseif (Auth::guard('pegawai')->check()) {
            $pegawai = Auth::guard('pegawai')->user();

            if ($pegawai->jabatan && strtolower($pegawai->jabatan->NAMA_JABATAN) != 'cs') {
                return response()->json(['message' => 'Only CS allowed'], 403);
            }

            $diskusi->ID_PEGAWAI = $pegawai->ID_PEGAWAI;
            $diskusi->save();

            return response()->json([
                'message' => 'Message added from pegawai (CS)',
                'data' => $diskusi->load(['pegawai'])
            ]);
        }

        return response()->json(['message' => 'Unauthorized'], 401);
    }

    public function customerDiscussions()
    {
        $pembeli = Auth::guard('pembeli')->user();
        if (!$pembeli) return response()->json(['message' => 'Unauthorized'], 401);

        $diskusi = Diskusi::with(['barang', 'pegawai'])
            ->where('ID_PEMBELI', $pembeli->ID_PEMBELI)
            ->orderBy('ID_DISKUSI', 'desc')
            ->get();

        return response()->json(['data' => $diskusi]);
    }

    public function productDiscussions($barangId)
    {
        $diskusi = Diskusi::with(['pembeli', 'pegawai'])
            ->where('ID_BARANG', $barangId)
            ->orderBy('ID_DISKUSI', 'asc')
            ->get();

        return response()->json(['data' => $diskusi]);
    }

    public function csDiscussions()
    {
        $pegawai = Auth::guard('pegawai')->user();
        if (!$pegawai || strtolower($pegawai->jabatan->NAMA_JABATAN) != 'cs') {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $diskusi = Diskusi::with(['barang', 'pembeli'])
            ->where('ID_PEGAWAI', $pegawai->ID_PEGAWAI)
            ->orderBy('ID_DISKUSI', 'desc')
            ->get();

        return response()->json(['data' => $diskusi]);
    }

}