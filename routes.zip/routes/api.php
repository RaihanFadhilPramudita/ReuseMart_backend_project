<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Mail;

use App\Http\Controllers\PembeliController;
use App\Http\Controllers\PenitipController;
use App\Http\Controllers\OrganisasiController;
use App\Http\Controllers\PegawaiController;

use App\Http\Controllers\AlamatController;
use App\Http\Controllers\BarangController;
use App\Http\Controllers\KategoriBarangController;
use App\Http\Controllers\PenitipanController;
use App\Http\Controllers\DetailPenitipanController;
use App\Http\Controllers\TransaksiController;
use App\Http\Controllers\DetailTransaksiController;
use App\Http\Controllers\PengirimanController;
use App\Http\Controllers\PengambilanController;
use App\Http\Controllers\MerchandiseController;
use App\Http\Controllers\RedeemMerchController;
use App\Http\Controllers\DetailRedeemController;
use App\Http\Controllers\DonasiController;
use App\Http\Controllers\RequestDonasiController;
use App\Http\Controllers\DiskusiController;
use App\Http\Controllers\JabatanController;
use App\Http\Controllers\KomisiController;

Route::prefix('auth/pembeli')->group(function () {
    Route::post('register', [PembeliController::class, 'register']);
    Route::post('login', [PembeliController::class, 'login']);
    Route::post('forgot-password', [PembeliController::class, 'forgotPassword']);
    Route::post('reset-password', [PembeliController::class, 'resetPassword']);
});

Route::prefix('auth/penitip')->group(function () {
    Route::post('login', [PenitipController::class, 'login']);
    Route::post('register', [PenitipController::class, 'register']);
    Route::post('forgot-password', [PenitipController::class, 'forgotPassword']);
});

Route::prefix('auth/organisasi')->group(function () {
    Route::post('register', [OrganisasiController::class, 'register']);
    Route::post('login', [OrganisasiController::class, 'login']);
    Route::post('forgot-password', [OrganisasiController::class, 'forgotPassword']);
});

Route::prefix('auth/pegawai')->group(function () {
    Route::post('login', [PegawaiController::class, 'login']);
    Route::post('register', [PegawaiController::class, 'register']);
    Route::post('reset-password', [PegawaiController::class, 'resetPasswordByBirthdate']);
});

Route::get('barang', [BarangController::class, 'index']);
Route::get('barang/search', [BarangController::class, 'search']);
Route::get('barang/{id}', [BarangController::class, 'show']);

Route::get('kategori', [KategoriBarangController::class, 'index']);
Route::get('kategori/{id}', [KategoriBarangController::class, 'show']);
Route::get('kategori/{id}/barang', [KategoriBarangController::class, 'items']);

Route::get('diskusi/barang/{barangId}', [DiskusiController::class, 'index']);

Route::middleware('auth:sanctum')->group(function () {
    Route::post('logout', function (Request $request) {
        $request->user()->currentAccessToken()->delete();
        return response()->json(['message' => 'Logged out successfully']);
    });
    
    Route::middleware('auth:sanctum,pembeli')->prefix('pembeli')->group(function () {
        Route::get('profile', [PembeliController::class, 'profile']);
        Route::put('profile', [PembeliController::class, 'update']);
        Route::post('change-password', [PembeliController::class, 'changePassword']);
        Route::get('transaksi', [PembeliController::class, 'orderHistory']);
        
        Route::get('alamat/show', [AlamatController::class, 'index']);
        Route::get('alamat/search', [AlamatController::class, 'index']);
        Route::post('alamat', [AlamatController::class, 'store']);
        Route::get('alamat/{id}', [AlamatController::class, 'show']);
        Route::put('alamat/{id}', [AlamatController::class, 'update']);
        Route::delete('alamat/{id}', [AlamatController::class, 'destroy']);
        
        Route::get('transaksi/show', [TransaksiController::class, 'index']);
        Route::get('transaksi/search', [TransaksiController::class, 'search']);
        Route::post('transaksi', [TransaksiController::class, 'store']);
        Route::get('transaksi/{id}', [TransaksiController::class, 'show']);
        Route::post('transaksi/{id}/upload-bukti', [TransaksiController::class, 'uploadPaymentProof']);
        Route::post('transaksi/{id}/cancel', [TransaksiController::class, 'cancel']);
        
        Route::post('diskusi', [DiskusiController::class, 'store']);
        Route::get('diskusi', [DiskusiController::class, 'customerDiscussions']);
        
        Route::get('redeem', [RedeemMerchController::class, 'customerRedemptions']);
        Route::post('redeem', [RedeemMerchController::class, 'store']);
        Route::post('redeem/{id}/cancel', [RedeemMerchController::class, 'cancel']);
        Route::post('logout', [PembeliController::class, 'logout']);
    });
    
    Route::middleware('auth:sanctum,penitip')->prefix('penitip')->group(function () {
        Route::get('profile', [PenitipController::class, 'profile']);
        Route::put('profile', [PenitipController::class, 'update']);
        Route::post('change-password', [PenitipController::class, 'changePassword']);
        Route::get('barang', [PenitipController::class, 'itemHistory']);
        Route::get('penitipan', [PenitipController::class, 'depositHistory']);
        Route::get('saldo', [PenitipController::class, 'showBalance']);
        Route::get('komisi', [KomisiController::class, 'depositorCommissionHistory']);
        
        Route::post('penitipan/{id}/extend', [PenitipanController::class, 'extend']);
        Route::post('penitipan/{id}/cancel', [PenitipanController::class, 'cancel']);
        Route::post('logout', [PenitipController::class, 'logout']);
    });
    
    Route::middleware('auth:sanctum,organisasi')->prefix('organisasi')->group(function () {
        Route::get('profile', [OrganisasiController::class, 'profile']);
        Route::put('profile', [OrganisasiController::class, 'update']);
        Route::post('change-password', [OrganisasiController::class, 'changePassword']);
        
        Route::get('request', [OrganisasiController::class, 'donationRequests']);
        Route::post('request', [RequestDonasiController::class, 'store']);
        Route::put('request/{id}', [RequestDonasiController::class, 'update']);
        Route::delete('request/{id}', [RequestDonasiController::class, 'destroy']);
        
        Route::get('donasi', [OrganisasiController::class, 'donationsReceived']);

        Route::post('logout', [OrganisasiController::class, 'logout']);
    });
    
    Route::middleware(['auth:sanctum', 'can:admin-access'])->prefix('admin')->group(function () {
        Route::apiResource('pegawai', PegawaiController::class);
        Route::get('pegawai/search', [PegawaiController::class, 'search']);
        Route::get('pegawai/{id}/commissions', [PegawaiController::class, 'commissions']);

        Route::apiResource('jabatan', JabatanController::class);
        Route::get('jabatan/{id}/employees', [JabatanController::class, 'employees']);

        Route::apiResource('organisasi', OrganisasiController::class, ['except' => ['store']]);
        Route::get('organisasi/search', [OrganisasiController::class, 'search']);

        Route::apiResource('merchandise', MerchandiseController::class);
        Route::put('merchandise/{id}/stock', [MerchandiseController::class, 'updateStock']);

        Route::post('logout', [PegawaiController::class, 'logout']);
    });

    Route::middleware(['auth:sanctum', 'can:owner-access'])->prefix('owner')->group(function () {
        Route::get('report/sales', [TransaksiController::class, 'salesReport']);
        Route::get('report/inventory', [BarangController::class, 'inventoryReport']);
        Route::get('report/commissions', [KomisiController::class, 'commissionReport']);
        Route::get('report/donations', [DonasiController::class, 'report']);

        Route::apiResource('donasi', DonasiController::class);
        Route::post('logout', [PegawaiController::class, 'logout']);
    });

    Route::middleware(['auth:sanctum', 'can:cs-access'])->prefix('cs')->group(function () {
        Route::apiResource('pembeli', PembeliController::class, ['except' => ['store', 'destroy']]);
        Route::get('pembeli/search', [PembeliController::class, 'search']);
        Route::apiResource('penitip', PenitipController::class);
        Route::get('penitip/search', [PenitipController::class, 'search']);
        Route::get('transaksi', [TransaksiController::class, 'index']);
        Route::get('transaksi/{id}', [TransaksiController::class, 'show']);
        Route::post('transaksi/{id}/verify-payment', [TransaksiController::class, 'verifyPayment']);
        Route::get('diskusi', [DiskusiController::class, 'index']);
        Route::post('diskusi', [DiskusiController::class, 'store']);
        Route::get('redeem', [RedeemMerchController::class, 'index']);
        Route::get('redeem/{id}', [RedeemMerchController::class, 'show']);
        Route::post('logout', [PegawaiController::class, 'logout']);
    });

    Route::middleware(['auth:sanctum', 'can:gudang-access'])->prefix('gudang')->group(function () {
        Route::apiResource('barang', BarangController::class);
        Route::post('barang/{id}/sold-out', [BarangController::class, 'soldOut']);
        Route::apiResource('kategori', KategoriBarangController::class);
        Route::apiResource('penitipan', PenitipanController::class);
        Route::get('penitipan/expired', [PenitipanController::class, 'expiredConsignments']);
        Route::get('penitipan/past-due', [PenitipanController::class, 'pastDueConsignments']);
        Route::resource('penitipan.items', DetailPenitipanController::class);
        Route::post('transaksi/{id}/update-status', [TransaksiController::class, 'updateStatus']);
        Route::apiResource('pengiriman', PengirimanController::class);
        Route::apiResource('pengambilan', PengambilanController::class);
        Route::post('pengambilan/{id}/cancel', [PengambilanController::class, 'confirmCancellation']);
        Route::resource('transaksi.items', DetailTransaksiController::class);
        Route::apiResource('donasi', DonasiController::class, ['except' => ['destroy', 'update']]);
        Route::apiResource('request-donasi', RequestDonasiController::class);
        Route::get('request-donasi/pending', [RequestDonasiController::class, 'pendingRequests']);
        Route::post('logout', [PegawaiController::class, 'logout']);
    });

    Route::middleware(['auth:sanctum', 'can:kurir-access'])->prefix('kurir')->group(function () {
        Route::get('pengiriman', [PengirimanController::class, 'index']);
        Route::get('pengiriman/{id}', [PengirimanController::class, 'show']);
        Route::post('pengiriman/{id}/update-status', [PengirimanController::class, 'updateStatus']);
        Route::post('logout', [PegawaiController::class, 'logout']);
    });

    Route::middleware(['auth:sanctum', 'can:hunter-access'])->prefix('hunter')->group(function () {
        Route::get('komisi', [KomisiController::class, 'index']);
        Route::get('komisi/{id}', [KomisiController::class, 'show']);
        Route::post('logout', [PegawaiController::class, 'logout']);
    });

    Route::prefix('redeem')->group(function () {
        Route::get('{redeemId}/items', [DetailRedeemController::class, 'index']);
        Route::post('{redeemId}/items', [DetailRedeemController::class, 'store']);
        Route::get('{redeemId}/items/{merchandiseId}', [DetailRedeemController::class, 'show']);
        Route::put('{redeemId}/items/{merchandiseId}', [DetailRedeemController::class, 'update']);
        Route::delete('{redeemId}/items/{merchandiseId}', [DetailRedeemController::class, 'destroy']);
    });
});